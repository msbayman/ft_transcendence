from django.apps import AppConfig


class Oauth242Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'oauth2_42'
