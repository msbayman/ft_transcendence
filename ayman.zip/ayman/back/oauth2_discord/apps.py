from django.apps import AppConfig


class Oauth2DiscordConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'oauth2_discord'
