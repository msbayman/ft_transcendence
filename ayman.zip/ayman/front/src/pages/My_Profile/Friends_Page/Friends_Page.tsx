import React from 'react'

export const Friends_Page = () => {
  return (
    <div>Friends_Page</div>
  )
}

export default Friends_Page