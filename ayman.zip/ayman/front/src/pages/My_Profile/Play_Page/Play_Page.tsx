import React from 'react'

const Play_Page = () => {
  return (
    <div>Play_Page</div>
  )
}

export default Play_Page