import React from 'react'

const Settings_Page = () => {
  return (
    <div>Settings_Page</div>
  )
}

export default Settings_Page