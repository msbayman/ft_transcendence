import React from 'react'

export const Shop_Page = () => {
  return (
    <div>Shop_Page</div>
  )
}

export default Shop_Page