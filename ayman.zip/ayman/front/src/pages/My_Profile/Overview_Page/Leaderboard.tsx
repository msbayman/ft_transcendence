// import React from "react";
import "./Leaderboard.css";

const Leaderboard = () => {
  return (
    <div className="All_Content_Leaderboard">
      <div className="Title_Leaderboard">
        <div className="The_Title_Leaderboard">Leaderboard</div>
        <div className="Button_More">More</div>
      </div>
      <div className="Table_Leaderboard">
        <div className="Title_Table_Leaderboard">
          <div className="the_Name Rank">Rank</div>
          <div className="the_Name UserName"> UserName</div>
          <div className="the_Name Top10">Top 10</div>
          <div className="the_Name Score">Score</div>
        </div>
        <div className="Inside_Leaderboard">
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
          <p>sdfsdfdsfdsf</p>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;
