import React from 'react'
import "./Online_Friends_Overview.css"

const Online_Friends_Overview = () => {
  return (
    <div className="all_content_Online">
      <div className="Title_Onlin">
        <div className="the_title">Online Friends</div>
      </div>
      <div className="Inside_Onlin_Friends">
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
        <p>asdsa</p>
      </div>
    </div>
  );
}

export default Online_Friends_Overview